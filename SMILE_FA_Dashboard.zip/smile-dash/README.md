# SMILE Facial Asymmetry — Analytics Dashboard (R Shiny)

Reads the SMILE-FA results Google Sheet and presents an educational, hi-tech
analytics dashboard consistent with the SMILE poster aesthetic.

## Files
- `SMILEFA.R` — the whole dashboard (single file)
- `cover_b64.txt` — base64 cover image, loaded by `SMILEFA.R`

## 1. Make the sheet readable (required)
Open the sheet → **Share → General access → Anyone with the link → Viewer**.
The app reads it via the public CSV endpoint — no login, no API key.
Sheet ID is already set in `SMILEFA.R` (`SHEET_ID`). If the results tab is not named
`Results`, change `SHEET_TAB`.

Until real rows exist (or if the sheet is unreachable), the app shows clearly
labelled **demo data** so every chart renders.

## 2. Run locally (to test)
Install R, then in the app folder:
```r
install.packages(c("shiny","bslib","dplyr","tidyr","ggplot2",
                   "plotly","DT","lubridate","scales"))
shiny::runApp("SMILEFA.R")
```

## 3a. Deploy to shinyapps.io (recommended — most reliable)
```r
install.packages("rsconnect")
rsconnect::setAccountInfo(name="<acct>", token="<token>", secret="<secret>")
rsconnect::deployApp(".")   # run from the app folder
```
Free tier: 5 apps, 25 active hours/month. Full package support; the CSV read works as-is.

## 3b. Deploy to GitHub Pages via shinylive (no server)
Compiles the app to WebAssembly (runs in the browser). Requires the sheet to be
public (step 1), because the browser fetches the CSV directly.
```r
install.packages("shinylive")
shinylive::export(appdir = ".", destdir = "site")
# preview:  httpuv::runStaticServer("site")
```
Push the `site/` folder to a `gh-pages` branch (or `/docs`) and enable Pages.
Notes: `googlesheets4` auth does **not** run in wasm — that is why this app uses
the public CSV URL instead. If Google's CSV endpoint blocks the cross-origin
request in the browser, publish the sheet to the web (File → Share → Publish to
web → CSV) and use that URL in `CSV_URL`.

## Tabs
Overview · Asymmetry · Metric Explorer · Flags & Quality · Data · **Learn**
(clinical basis, forehead-sparing rule, metric dictionary, references).

RESEARCH USE ONLY · thresholds provisional · not a diagnostic device.
